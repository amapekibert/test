// Quazi Programming Language
// Copyright (c) 2026 quazilang
// SPDX-License-Identifier: 0BSD

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Span {
    pub line: usize,
    pub col: usize,
    pub start: usize,
    pub end: usize,
}

impl Span {
    pub fn new(line: usize, col: usize, start: usize, end: usize) -> Self {
        Self {
            line,
            col,
            start,
            end,
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum TokenKind {
    // literals
    Int(i64),
    Float(f64),
    StringLit(String),
    ByteStringLit(Vec<u8>),
    Ident(String),
    Error(String),

    // keywords
    Fn,
    Var,
    Const,
    Return,
    If,
    Else,
    While,
    Import,
    Impl,
    Struct,
    Union,
    Trait,
    Enum,
    Match,
    As,
    For,
    Pub,
    Unsafe,
    Break,
    Continue,

    // types
    Int8,
    Int16,
    Int32,
    Int64,
    Uint8,
    Uint16,
    Uint32,
    Uint64,
    Isize,
    Usize,
    Float16,
    Float32,
    Float64,
    Bool,
    Str,
    Bytes,
    Void,
    Any,
    True,
    False,

    // symbols
    LParen,    // (
    RParen,    // )
    LBracket,  // [
    RBracket,  // ]
    LBrace,    // {
    RBrace,    // }
    Semicolon, // ;
    Colon,     // :
    Dot,       // .
    Comma,     // ,
    Ampersand, // &
    Pipe,      // |
    Caret,     // ^
    Hash,      // #
    At,        // @
    DotDot,    // ..
    DotDotEq,  // ..=
    DotDotDot, // ...
    Percent,   // %

    // operators
    Eq,       // =
    FatArrow, // =>
    Plus,     // +
    Minus,    // -
    Star,     // *
    StarStar, // **
    Slash,    // /
    Lt,       // <
    Gt,       // >
    Shl,      // <<
    Shr,      // >>
    LtEq,     // <=
    GtEq,     // >=
    EqEq,     // ==
    NotEq,    // !=
    Bang,     // !

    // compound assignment
    PlusEq,    // +=
    MinusEq,   // -=
    StarEq,    // *=
    SlashEq,   // /=
    PercentEq, // %=

    // increment / decrement
    PlusPlus,   // ++
    MinusMinus, // --

    // try operator
    Question, // ?

    // type alias
    Type,

    // directives
    Platform, // platform

    Eof,
}

#[derive(Debug, Clone, PartialEq)]
pub struct Token {
    pub kind: TokenKind,
    pub span: Span,
}

impl Token {
    pub fn new(kind: TokenKind, span: Span) -> Self {
        Self { kind, span }
    }

    pub fn eof(span: Span) -> Self {
        Self {
            kind: TokenKind::Eof,
            span,
        }
    }
}

impl std::fmt::Display for TokenKind {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            TokenKind::Int(value) => write!(f, "integer literal {}", value),
            TokenKind::Float(value) => write!(f, "float literal {}", value),
            TokenKind::StringLit(_) => write!(f, "string literal"),
            TokenKind::ByteStringLit(_) => write!(f, "byte string literal"),
            TokenKind::Ident(name) => write!(f, "identifier {}", name),
            TokenKind::Error(msg) => write!(f, "lexer error {}", msg),

            TokenKind::Fn => write!(f, "fn"),
            TokenKind::Var => write!(f, "var"),
            TokenKind::Const => write!(f, "const"),
            TokenKind::Return => write!(f, "ret"),
            TokenKind::If => write!(f, "if"),
            TokenKind::Else => write!(f, "else"),
            TokenKind::While => write!(f, "while"),
            TokenKind::Import => write!(f, "import"),
            TokenKind::Impl => write!(f, "impl"),
            TokenKind::Struct => write!(f, "struct"),
            TokenKind::Union => write!(f, "union"),
            TokenKind::Trait => write!(f, "trait"),
            TokenKind::Enum => write!(f, "enum"),
            TokenKind::Match => write!(f, "match"),
            TokenKind::As => write!(f, "as"),
            TokenKind::For => write!(f, "for"),
            TokenKind::Pub => write!(f, "pub"),
            TokenKind::Unsafe => write!(f, "unsafe"),
            TokenKind::Break => write!(f, "break"),
            TokenKind::Continue => write!(f, "continue"),

            TokenKind::Int8 => write!(f, "i8"),
            TokenKind::Int16 => write!(f, "i16"),
            TokenKind::Int32 => write!(f, "i32"),
            TokenKind::Int64 => write!(f, "i64"),
            TokenKind::Uint8 => write!(f, "u8"),
            TokenKind::Uint16 => write!(f, "u16"),
            TokenKind::Uint32 => write!(f, "u32"),
            TokenKind::Uint64 => write!(f, "u64"),
            TokenKind::Isize => write!(f, "isize"),
            TokenKind::Usize => write!(f, "usize"),
            TokenKind::Float16 => write!(f, "f16"),
            TokenKind::Float32 => write!(f, "f32"),
            TokenKind::Float64 => write!(f, "f64"),
            TokenKind::Bool => write!(f, "bool"),
            TokenKind::Str => write!(f, "str"),
            TokenKind::Bytes => write!(f, "bytes"),
            TokenKind::Void => write!(f, "void"),
            TokenKind::Any => write!(f, "any"),
            TokenKind::True => write!(f, "true"),
            TokenKind::False => write!(f, "false"),

            TokenKind::LParen => write!(f, "("),
            TokenKind::RParen => write!(f, ")"),
            TokenKind::LBracket => write!(f, "["),
            TokenKind::RBracket => write!(f, "]"),
            TokenKind::LBrace => write!(f, "{{"),
            TokenKind::RBrace => write!(f, "}}"),
            TokenKind::Semicolon => write!(f, ";"),
            TokenKind::Colon => write!(f, ":"),
            TokenKind::Dot => write!(f, "."),
            TokenKind::Comma => write!(f, ","),
            TokenKind::Ampersand => write!(f, "&"),
            TokenKind::Pipe => write!(f, "|"),
            TokenKind::Caret => write!(f, "^"),
            TokenKind::Hash => write!(f, "#"),
            TokenKind::At => write!(f, "@"),
            TokenKind::DotDot => write!(f, ".."),
            TokenKind::DotDotEq => write!(f, "..="),
            TokenKind::DotDotDot => write!(f, "..."),
            TokenKind::Percent => write!(f, "%"),

            TokenKind::Eq => write!(f, "="),
            TokenKind::FatArrow => write!(f, "=>"),
            TokenKind::Plus => write!(f, "+"),
            TokenKind::Minus => write!(f, "-"),
            TokenKind::Star => write!(f, "*"),
            TokenKind::StarStar => write!(f, "**"),
            TokenKind::Slash => write!(f, "/"),
            TokenKind::Lt => write!(f, "<"),
            TokenKind::Gt => write!(f, ">"),
            TokenKind::Shl => write!(f, "<<"),
            TokenKind::Shr => write!(f, ">>"),
            TokenKind::LtEq => write!(f, "<="),
            TokenKind::GtEq => write!(f, ">="),
            TokenKind::EqEq => write!(f, "=="),
            TokenKind::NotEq => write!(f, "!="),
            TokenKind::Bang => write!(f, "!"),

            TokenKind::PlusEq => write!(f, "+="),
            TokenKind::MinusEq => write!(f, "-="),
            TokenKind::StarEq => write!(f, "*="),
            TokenKind::SlashEq => write!(f, "/="),
            TokenKind::PercentEq => write!(f, "%="),
            TokenKind::PlusPlus => write!(f, "++"),
            TokenKind::MinusMinus => write!(f, "--"),
            TokenKind::Question => write!(f, "?"),

            TokenKind::Type => write!(f, "type"),
            TokenKind::Platform => write!(f, "platform"),
            TokenKind::Eof => write!(f, "EOF"),
        }
    }
}
