// Quazi Programming Language
// Copyright (c) 2026 quazilang
// SPDX-License-Identifier: 0BSD

pub mod token;
use token::{Span, Token, TokenKind};

pub struct Lexer {
    input: Vec<char>,
    pos: usize,
    line: usize,
    col: usize,
}

impl Lexer {
    pub fn new(input: &str) -> Self {
        Self {
            input: input.chars().collect(),
            pos: 0,
            line: 1,
            col: 1,
        }
    }

    fn peek(&self) -> Option<char> {
        self.input.get(self.pos).copied()
    }

    fn peek_next(&self) -> Option<char> {
        self.input.get(self.pos + 1).copied()
    }

    fn advance(&mut self) -> Option<char> {
        let ch = self.input.get(self.pos).copied();
        if let Some(c) = ch {
            self.pos += 1;
            if c == '\n' {
                self.line += 1;
                self.col = 1;
            } else {
                self.col += 1;
            }
        }
        ch
    }

    fn make_span(&self, start: usize, end: usize, line: usize, col: usize) -> Span {
        Span {
            line,
            col,
            start,
            end,
        }
    }

    fn skip_whitespace_and_comments(&mut self) {
        loop {
            match self.peek() {
                Some(ch) if ch.is_whitespace() => {
                    self.advance();
                }
                Some('/') if self.peek_next() == Some('/') => {
                    // consume //
                    self.advance();
                    self.advance();

                    // skip until newline (newline itself is handled by whitespace pass)
                    while let Some(c) = self.peek() {
                        if c == '\n' {
                            break;
                        }
                        self.advance();
                    }
                }
                _ => break,
            }
        }
    }

    fn read_string(&mut self, start: usize, line: usize, col: usize) -> Token {
        let mut s = String::new();

        while let Some(ch) = self.advance() {
            match ch {
                '"' => {
                    let span = self.make_span(start, self.pos, line, col);
                    return Token::new(TokenKind::StringLit(s), span);
                }
                '\\' => match self.read_escape() {
                    Ok(Some(mapped)) => s.push(mapped),
                    Ok(None) => {}
                    Err(message) => {
                        let span = self.make_span(start, self.pos, line, col);
                        return Token::new(TokenKind::Error(message), span);
                    }
                },
                other => s.push(other),
            }
        }

        // Unterminated string: still emit StringLit so parser can continue.
        let span = self.make_span(start, self.pos, line, col);
        Token::new(TokenKind::StringLit(s), span)
    }

    fn read_escape(&mut self) -> Result<Option<char>, String> {
        let Some(escape) = self.advance() else {
            return Err("unterminated escape sequence".to_string());
        };

        let value = match escape {
            'a' => '\u{0007}',
            'b' => '\u{0008}',
            'e' => '\u{001b}',
            'f' => '\u{000c}',
            'n' => '\n',
            'r' => '\r',
            't' => '\t',
            'v' => '\u{000b}',
            '\\' => '\\',
            '\'' => '\'',
            '"' => '"',
            '?' => '?',
            '\n' => {
                while self.peek().is_some_and(char::is_whitespace) {
                    self.advance();
                }
                return Ok(None);
            }
            '\r' if self.peek() == Some('\n') => {
                self.advance();
                while self.peek().is_some_and(char::is_whitespace) {
                    self.advance();
                }
                return Ok(None);
            }
            'x' => return self.read_hex_escape().map(Some),
            'u' => return self.read_unicode_escape().map(Some),
            'U' => return self.read_fixed_unicode_escape(8).map(Some),
            '0'..='7' => return self.read_octal_escape(escape).map(Some),
            other => return Err(format!("unknown escape sequence '\\{other}'")),
        };
        Ok(Some(value))
    }

    fn read_hex_escape(&mut self) -> Result<char, String> {
        let value = self.read_digits(16, 2, "hexadecimal escape")?;
        if value > 0x7f {
            return Err("hexadecimal escape must be in the ASCII range (00-7F)".to_string());
        }
        char::from_u32(value).ok_or_else(|| "invalid hexadecimal escape".to_string())
    }

    fn read_unicode_escape(&mut self) -> Result<char, String> {
        if self.peek() != Some('{') {
            return self.read_fixed_unicode_escape(4);
        }
        self.advance();

        let mut digits = String::new();
        while let Some(ch) = self.peek() {
            if ch == '}' {
                self.advance();
                break;
            }
            if ch == '_' {
                self.advance();
                continue;
            }
            if !ch.is_ascii_hexdigit() {
                return Err(format!("invalid character '{ch}' in Unicode escape"));
            }
            if digits.len() == 6 {
                return Err("Unicode escape may contain at most 6 hex digits".to_string());
            }
            digits.push(ch);
            self.advance();
        }

        if digits.is_empty() {
            return Err("Unicode escape must contain 1 to 6 hex digits".to_string());
        }
        if self.input.get(self.pos.saturating_sub(1)) != Some(&'}') {
            return Err("unterminated Unicode escape; expected '}'".to_string());
        }

        let value = u32::from_str_radix(&digits, 16).expect("validated Unicode digits");
        char::from_u32(value)
            .ok_or_else(|| format!("Unicode escape U+{value:04X} is not a valid scalar value"))
    }

    fn read_fixed_unicode_escape(&mut self, count: usize) -> Result<char, String> {
        let value = self.read_digits(16, count, "Unicode escape")?;
        char::from_u32(value)
            .ok_or_else(|| format!("Unicode escape U+{value:04X} is not a valid scalar value"))
    }

    fn read_octal_escape(&mut self, first: char) -> Result<char, String> {
        let mut value = first.to_digit(8).expect("validated octal digit");
        for _ in 1..3 {
            let Some(ch @ '0'..='7') = self.peek() else {
                break;
            };
            self.advance();
            value = value * 8 + ch.to_digit(8).expect("validated octal digit");
        }
        char::from_u32(value).ok_or_else(|| "invalid octal escape".to_string())
    }

    fn read_digits(&mut self, radix: u32, count: usize, name: &str) -> Result<u32, String> {
        let mut value = 0;
        for _ in 0..count {
            let Some(ch) = self.advance() else {
                return Err(format!("incomplete {name}; expected {count} digits"));
            };
            let Some(digit) = ch.to_digit(radix) else {
                return Err(format!("invalid digit '{ch}' in {name}"));
            };
            value = value * radix + digit;
        }
        Ok(value)
    }

    fn read_raw_string(&mut self, start: usize, line: usize, col: usize) -> Token {
        let mut s = String::new();

        while let Some(ch) = self.advance() {
            if ch == '`' {
                let span = self.make_span(start, self.pos, line, col);
                return Token::new(TokenKind::StringLit(s), span);
            }
            s.push(ch);
        }

        let span = self.make_span(start, self.pos, line, col);
        Token::new(TokenKind::Error("unterminated raw string".to_string()), span)
    }

    fn read_byte_string(&mut self, start: usize, line: usize, col: usize, raw: bool) -> Token {
        let mut bytes = Vec::new();

        while let Some(ch) = self.advance() {
            if ch == '"' {
                let span = self.make_span(start, self.pos, line, col);
                return Token::new(TokenKind::ByteStringLit(bytes), span);
            }
            if ch == '\\' && !raw {
                match self.read_byte_escape() {
                    Ok(Some(byte)) => bytes.push(byte),
                    Ok(None) => {}
                    Err(message) => {
                        let span = self.make_span(start, self.pos, line, col);
                        return Token::new(TokenKind::Error(message), span);
                    }
                }
            } else {
                let mut encoded = [0u8; 4];
                bytes.extend_from_slice(ch.encode_utf8(&mut encoded).as_bytes());
            }
        }

        let span = self.make_span(start, self.pos, line, col);
        Token::new(
            TokenKind::Error("unterminated byte string".to_string()),
            span,
        )
    }

    fn read_byte_escape(&mut self) -> Result<Option<u8>, String> {
        let Some(escape) = self.advance() else {
            return Err("unterminated byte escape sequence".to_string());
        };
        let byte = match escape {
            'a' => 0x07,
            'b' => 0x08,
            'e' => 0x1b,
            'f' => 0x0c,
            'n' => b'\n',
            'r' => b'\r',
            't' => b'\t',
            'v' => 0x0b,
            '\\' => b'\\',
            '\'' => b'\'',
            '"' => b'"',
            '?' => b'?',
            '\n' => {
                while self.peek().is_some_and(char::is_whitespace) {
                    self.advance();
                }
                return Ok(None);
            }
            '\r' if self.peek() == Some('\n') => {
                self.advance();
                while self.peek().is_some_and(char::is_whitespace) {
                    self.advance();
                }
                return Ok(None);
            }
            'x' => {
                let value = self.read_digits(16, 2, "byte hexadecimal escape")?;
                return Ok(Some(value as u8));
            }
            first @ '0'..='7' => {
                let mut value = first.to_digit(8).expect("validated octal digit");
                for _ in 1..3 {
                    let Some(ch @ '0'..='7') = self.peek() else {
                        break;
                    };
                    self.advance();
                    value = value * 8 + ch.to_digit(8).expect("validated octal digit");
                }
                if value > u8::MAX as u32 {
                    return Err("byte octal escape must fit in 8 bits".to_string());
                }
                return Ok(Some(value as u8));
            }
            'u' | 'U' => {
                return Err("Unicode escapes are not allowed in byte strings".to_string());
            }
            other => return Err(format!("unknown byte escape sequence '\\{other}'")),
        };
        Ok(Some(byte))
    }

    fn read_number(&mut self, first: char, start: usize, line: usize, col: usize) -> Token {
        let mut s = String::from(first);
        let mut is_float = false;

        while let Some(ch) = self.peek() {
            if ch.is_ascii_digit() {
                s.push(ch);
                self.advance();
            } else if ch == '.' && !is_float {
                // only treat as float if next char is digit
                if self.peek_next().is_some_and(|n| n.is_ascii_digit()) {
                    is_float = true;
                    s.push(ch);
                    self.advance();
                } else {
                    break;
                }
            } else {
                break;
            }
        }

        let kind = if is_float {
            TokenKind::Float(s.parse().unwrap_or(0.0))
        } else {
            TokenKind::Int(s.parse().unwrap_or(0))
        };

        let span = self.make_span(start, self.pos, line, col);
        Token::new(kind, span)
    }

    fn read_ident_or_keyword(
        &mut self,
        first: char,
        start: usize,
        line: usize,
        col: usize,
    ) -> Token {
        let mut s = String::from(first);

        while let Some(ch) = self.peek() {
            if ch.is_alphanumeric() || ch == '_' {
                s.push(ch);
                self.advance();
            } else {
                break;
            }
        }

        let kind = match s.as_str() {
            // keywords
            "fn" => TokenKind::Fn,
            "var" => TokenKind::Var,
            "const" => TokenKind::Const,
            "ret" => TokenKind::Return,
            "if" => TokenKind::If,
            "else" => TokenKind::Else,
            "while" => TokenKind::While,
            "import" => TokenKind::Import,
            "impl" => TokenKind::Impl,
            "struct" => TokenKind::Struct,
            "union" => TokenKind::Union,
            "trait" => TokenKind::Trait,
            "enum" => TokenKind::Enum,
            "match" => TokenKind::Match,
            "as" => TokenKind::As,
            "for" => TokenKind::For,
            "pub" => TokenKind::Pub,
            "unsafe" => TokenKind::Unsafe,
            "break" => TokenKind::Break,
            "continue" => TokenKind::Continue,
            "type" => TokenKind::Type,
            "platform" => TokenKind::Platform,

            // primitive types
            "i8" => TokenKind::Int8,
            "i16" => TokenKind::Int16,
            "i32" => TokenKind::Int32,
            "i64" => TokenKind::Int64,
            "u8" => TokenKind::Uint8,
            "u16" => TokenKind::Uint16,
            "u32" => TokenKind::Uint32,
            "u64" => TokenKind::Uint64,
            "isize" => TokenKind::Isize,
            "usize" => TokenKind::Usize,
            "f16" => TokenKind::Float16,
            "f32" => TokenKind::Float32,
            "f64" => TokenKind::Float64,
            "bool" => TokenKind::Bool,
            "str" => TokenKind::Str,
            "bytes" => TokenKind::Bytes,
            "void" => TokenKind::Void,
            "any" => TokenKind::Any,
            "true" => TokenKind::True,
            "false" => TokenKind::False,

            _ => TokenKind::Ident(s),
        };

        let span = self.make_span(start, self.pos, line, col);
        Token::new(kind, span)
    }

    fn lex_error(&self, ch: char, start: usize, line: usize, col: usize) -> Token {
        let escaped: String = ch.escape_default().collect();
        let span = self.make_span(start, self.pos, line, col);
        Token::new(
            TokenKind::Error(format!("unexpected character '{}'", escaped)),
            span,
        )
    }

    pub fn next_token(&mut self) -> Token {
        self.skip_whitespace_and_comments();

        let start = self.pos;
        let line = self.line;
        let col = self.col;

        match self.advance() {
            None => Token::eof(self.make_span(self.pos, self.pos, self.line, self.col)),
            Some(ch) => {
                let kind = match ch {
                    '(' => TokenKind::LParen,
                    ')' => TokenKind::RParen,
                    '[' => TokenKind::LBracket,
                    ']' => TokenKind::RBracket,
                    '{' => TokenKind::LBrace,
                    '}' => TokenKind::RBrace,
                    ';' => TokenKind::Semicolon,
                    ':' => TokenKind::Colon,
                    ',' => TokenKind::Comma,
                    '.' => {
                        if self.peek() == Some('.') {
                            self.advance();
                            if self.peek() == Some('.') {
                                self.advance();
                                TokenKind::DotDotDot
                            } else if self.peek() == Some('=') {
                                self.advance();
                                TokenKind::DotDotEq
                            } else {
                                TokenKind::DotDot
                            }
                        } else {
                            TokenKind::Dot
                        }
                    }
                    '&' => TokenKind::Ampersand,
                    '|' => TokenKind::Pipe,
                    '#' => TokenKind::Hash,
                    '@' => TokenKind::At,

                    '+' => {
                        if self.peek() == Some('=') {
                            self.advance();
                            TokenKind::PlusEq
                        } else if self.peek() == Some('+') {
                            self.advance();
                            TokenKind::PlusPlus
                        } else {
                            TokenKind::Plus
                        }
                    }
                    '-' => {
                        if self.peek() == Some('=') {
                            self.advance();
                            TokenKind::MinusEq
                        } else if self.peek() == Some('-') {
                            self.advance();
                            TokenKind::MinusMinus
                        } else {
                            TokenKind::Minus
                        }
                    }
                    '*' => {
                        if self.peek() == Some('=') {
                            self.advance();
                            TokenKind::StarEq
                        } else if self.peek() == Some('*') {
                            self.advance();
                            TokenKind::StarStar
                        } else {
                            TokenKind::Star
                        }
                    }
                    '/' => {
                        if self.peek() == Some('=') {
                            self.advance();
                            TokenKind::SlashEq
                        } else {
                            TokenKind::Slash
                        }
                    }
                    '%' => {
                        if self.peek() == Some('=') {
                            self.advance();
                            TokenKind::PercentEq
                        } else {
                            TokenKind::Percent
                        }
                    }

                    '<' => {
                        if self.peek() == Some('<') {
                            self.advance();
                            TokenKind::Shl
                        } else if self.peek() == Some('=') {
                            self.advance();
                            TokenKind::LtEq
                        } else {
                            TokenKind::Lt
                        }
                    }
                    '>' => {
                        if self.peek() == Some('>') {
                            self.advance();
                            TokenKind::Shr
                        } else if self.peek() == Some('=') {
                            self.advance();
                            TokenKind::GtEq
                        } else {
                            TokenKind::Gt
                        }
                    }
                    '^' => TokenKind::Caret,
                    '=' => {
                        if self.peek() == Some('=') {
                            self.advance();
                            TokenKind::EqEq
                        } else if self.peek() == Some('>') {
                            self.advance();
                            TokenKind::FatArrow
                        } else {
                            TokenKind::Eq
                        }
                    }
                    '!' => {
                        if self.peek() == Some('=') {
                            self.advance();
                            TokenKind::NotEq
                        } else {
                            TokenKind::Bang
                        }
                    }
                    '?' => TokenKind::Question,

                    'b' if self.peek() == Some('"') => {
                        self.advance();
                        return self.read_byte_string(start, line, col, false);
                    }
                    'b' if self.peek() == Some('r')
                        && self.input.get(self.pos + 1) == Some(&'"') =>
                    {
                        self.advance();
                        self.advance();
                        return self.read_byte_string(start, line, col, true);
                    }
                    '"' => return self.read_string(start, line, col),
                    '`' => return self.read_raw_string(start, line, col),

                    c if c.is_ascii_digit() => return self.read_number(c, start, line, col),
                    c if c.is_alphabetic() || c == '_' => {
                        return self.read_ident_or_keyword(c, start, line, col);
                    }

                    _ => return self.lex_error(ch, start, line, col),
                };

                let span = self.make_span(start, self.pos, line, col);
                Token::new(kind, span)
            }
        }
    }

    pub fn tokenize(&mut self) -> Vec<Token> {
        let mut tokens = Vec::new();

        loop {
            let tok = self.next_token();
            let is_eof = tok.kind == TokenKind::Eof;
            tokens.push(tok);
            if is_eof {
                break;
            }
        }

        tokens
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn emits_at_token_for_at_sign() {
        let mut lexer = Lexer::new("@");
        let tokens = lexer.tokenize();
        assert!(matches!(
            tokens.first().map(|t| &t.kind),
            Some(TokenKind::At)
        ));
        assert!(matches!(
            tokens.last().map(|t| &t.kind),
            Some(TokenKind::Eof)
        ));
    }

    #[test]
    fn emits_error_token_for_unknown_character() {
        let mut lexer = Lexer::new("$");
        let tokens = lexer.tokenize();
        assert!(matches!(
            tokens.first().map(|t| &t.kind),
            Some(TokenKind::Error(_))
        ));
    }

    #[test]
    fn isize_usize_are_keywords() {
        let mut lexer = Lexer::new("isize usize");
        let tokens = lexer.tokenize();
        assert!(matches!(tokens[0].kind, TokenKind::Isize));
        assert!(matches!(tokens[1].kind, TokenKind::Usize));
    }

    #[test]
    fn numeric_type_keywords_use_short_names() {
        let mut lexer = Lexer::new("i8 i16 i32 i64 u8 u16 u32 u64 f16 f32 f64");
        let tokens = lexer.tokenize();
        assert!(matches!(tokens[0].kind, TokenKind::Int8));
        assert!(matches!(tokens[1].kind, TokenKind::Int16));
        assert!(matches!(tokens[2].kind, TokenKind::Int32));
        assert!(matches!(tokens[3].kind, TokenKind::Int64));
        assert!(matches!(tokens[4].kind, TokenKind::Uint8));
        assert!(matches!(tokens[5].kind, TokenKind::Uint16));
        assert!(matches!(tokens[6].kind, TokenKind::Uint32));
        assert!(matches!(tokens[7].kind, TokenKind::Uint64));
        assert!(matches!(tokens[8].kind, TokenKind::Float16));
        assert!(matches!(tokens[9].kind, TokenKind::Float32));
        assert!(matches!(tokens[10].kind, TokenKind::Float64));
    }

    #[test]
    fn lexes_exclusive_and_inclusive_ranges() {
        let tokens = Lexer::new("0..5 0..=5").tokenize();
        assert!(matches!(tokens[1].kind, TokenKind::DotDot));
        assert!(matches!(tokens[4].kind, TokenKind::DotDotEq));
    }

    #[test]
    fn byte_strings_preserve_exact_bytes() {
        let tokens = Lexer::new(r#"b"A\xFF\0" br"\x41""#).tokenize();
        assert_eq!(
            tokens[0].kind,
            TokenKind::ByteStringLit(vec![b'A', 0xff, 0])
        );
        assert_eq!(tokens[1].kind, TokenKind::ByteStringLit(br"\x41".to_vec()));
    }
}

#[cfg(test)]
mod string_tests {
    use super::*;

    fn string_value(source: &str) -> String {
        match Lexer::new(source).next_token().kind {
            TokenKind::StringLit(value) => value,
            other => panic!("expected string literal, got {other:?}"),
        }
    }

    fn escape_error(source: &str) -> String {
        match Lexer::new(source).next_token().kind {
            TokenKind::Error(message) => message,
            other => panic!("expected escape error, got {other:?}"),
        }
    }

    #[test]
    fn quoted_strings_decode_simple_control_escapes() {
        assert_eq!(
            string_value(r#""\0\a\b\e\f\n\r\t\v\\\'\"\?""#),
            "\0\u{0007}\u{0008}\u{001b}\u{000c}\n\r\t\u{000b}\\\'\"?"
        );
    }

    #[test]
    fn quoted_strings_decode_numeric_escapes() {
        assert_eq!(
            string_value(r#""\x41\101\u263A\U0001F980\u{1F_980}""#),
            "AA☺🦀🦀"
        );
    }

    #[test]
    fn quoted_strings_support_line_continuations() {
        assert_eq!(string_value("\"first\\\n    second\""), "firstsecond");
    }

    #[test]
    fn quoted_strings_support_crlf_line_continuations() {
        assert_eq!(string_value("\"first\\\r\n    second\""), "firstsecond");
    }

    #[test]
    fn malformed_escapes_are_errors() {
        assert!(escape_error(r#""\q""#).contains("unknown escape"));
        assert!(escape_error(r#""\xG0""#).contains("invalid digit"));
        assert!(escape_error(r#""\xFF""#).contains("ASCII range"));
        assert!(escape_error(r#""\u12G4""#).contains("invalid digit"));
        assert!(escape_error(r#""\u{}""#).contains("1 to 6"));
        assert!(escape_error(r#""\u{D800}""#).contains("not a valid scalar"));
        assert!(escape_error(r#""\u{110000}""#).contains("not a valid scalar"));
    }

    #[test]
    fn quoted_strings_decode_ansi_escape() {
        assert_eq!(
            string_value(r#""\e[31mred\e[0m""#),
            "\u{001b}[31mred\u{001b}[0m"
        );
    }

    #[test]
    fn raw_strings_preserve_backslashes_and_quotes() {
        assert_eq!(
            string_value(r#"`\0\a\e\n\t\x41\101\u263A\U0001F980\u{1F980}"quoted"`"#),
            r#"\0\a\e\n\t\x41\101\u263A\U0001F980\u{1F980}"quoted""#
        );
    }

    #[test]
    fn raw_strings_can_span_lines() {
        assert_eq!(string_value("`first\nsecond`"), "first\nsecond");
    }

    #[test]
    fn unterminated_multiline_raw_strings_are_errors() {
        assert!(escape_error("`first\nsecond").contains("unterminated raw string"));
    }

}
